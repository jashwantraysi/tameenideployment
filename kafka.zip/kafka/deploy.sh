#!/bin/bash
# ============================================================
# Strimzi Kafka Deployment Script (Linux/Bash) - KRaft Mode
# ============================================================
# Usage: chmod +x deploy.sh && ./deploy.sh
# ============================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
GRAY='\033[0;37m'
NC='\033[0m'

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN} Strimzi Kafka Deployment (KRaft)${NC}"
echo -e "${CYAN}========================================${NC}"

# Step 1: Create namespace
echo -e "\n${YELLOW}[1/6] Creating kafka namespace...${NC}"
kubectl apply -f 01-namespace.yaml

# Step 2: Install Strimzi operator
echo -e "\n${YELLOW}[2/6] Installing Strimzi operator...${NC}"
kubectl create -f 'https://strimzi.io/install/latest?namespace=kafka' -n kafka 2>&1 || true

# Step 3: Wait for Strimzi operator to be ready
echo -e "\n${YELLOW}[3/6] Waiting for Strimzi operator to be ready...${NC}"
TIMEOUT=300
ELAPSED=0
READY=false

while [ "$READY" = false ] && [ $ELAPSED -lt $TIMEOUT ]; do
    PHASE=$(kubectl get pods -n kafka -l name=strimzi-cluster-operator -o jsonpath='{.items[*].status.phase}' 2>/dev/null)
    if [ "$PHASE" = "Running" ]; then
        READY=true
        echo -e "${GREEN}Strimzi operator is ready!${NC}"
    else
        echo -e "${GRAY}  Waiting... ($ELAPSED/$TIMEOUT seconds)${NC}"
        sleep 10
        ELAPSED=$((ELAPSED + 10))
    fi
done

if [ "$READY" = false ]; then
    echo -e "${RED}WARNING: Timed out waiting for operator. Continuing anyway...${NC}"
fi

# Step 4: Apply RBAC
echo -e "\n${YELLOW}[4/6] Applying RBAC bindings...${NC}"
kubectl apply -f 03-rbac.yaml

# Step 5: Deploy KafkaNodePool
echo -e "\n${YELLOW}[5/6] Deploying KafkaNodePool...${NC}"
kubectl apply -f 04-kafka-nodepool.yaml

# Step 6: Deploy Kafka cluster
echo -e "\n${YELLOW}[6/6] Deploying Kafka cluster (KRaft mode)...${NC}"
kubectl apply -f 05-kafka-cluster.yaml

# Final status
echo -e "\n${CYAN}========================================${NC}"
echo -e "${CYAN} Deployment initiated!${NC}"
echo -e "${CYAN}========================================${NC}"
echo -e "\n${YELLOW}Monitor with:${NC}"
echo "  kubectl get pods -n kafka -w"
echo -e "\n${YELLOW}Expected pods (all should be Running):${NC}"
echo "  - strimzi-cluster-operator-*    (1/1)"
echo "  - my-cluster-dual-role-0        (1/1)"
echo "  - my-cluster-entity-operator-*  (1/1)"
echo -e "\n${YELLOW}Check services with:${NC}"
echo "  kubectl get svc -n kafka"
