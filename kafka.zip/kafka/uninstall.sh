#!/bin/bash
# ============================================================
# Strimzi Kafka Uninstall Script (Linux/Bash)
# ============================================================
# Usage: chmod +x uninstall.sh && ./uninstall.sh
# ============================================================

RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${RED}========================================${NC}"
echo -e "${RED} Strimzi Kafka Uninstall${NC}"
echo -e "${RED}========================================${NC}"

read -p "Are you sure you want to remove Kafka from this cluster? (yes/no): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
    echo -e "${YELLOW}Aborted.${NC}"
    exit 0
fi

echo -e "\n${YELLOW}[1/6] Deleting Kafka cluster...${NC}"
kubectl delete -f 05-kafka-cluster.yaml --ignore-not-found

echo -e "\n${YELLOW}[2/6] Deleting KafkaNodePool...${NC}"
kubectl delete -f 04-kafka-nodepool.yaml --ignore-not-found

echo -e "\n${YELLOW}[3/6] Deleting Kafka topics...${NC}"
kubectl delete -f 06-kafka-topics.yaml --ignore-not-found

echo -e "\n${YELLOW}[4/6] Deleting RBAC bindings...${NC}"
kubectl delete -f 03-rbac.yaml --ignore-not-found

echo -e "\n${YELLOW}[5/6] Deleting Strimzi operator...${NC}"
kubectl delete -f 'https://strimzi.io/install/latest?namespace=kafka' -n kafka --ignore-not-found

echo -e "\n${YELLOW}[6/6] Deleting kafka namespace...${NC}"
kubectl delete namespace kafka --ignore-not-found

echo -e "\n${GREEN}Uninstall complete.${NC}"
